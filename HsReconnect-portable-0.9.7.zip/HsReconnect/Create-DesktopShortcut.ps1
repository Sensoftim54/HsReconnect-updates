﻿[CmdletBinding()]
param([string]$ShortcutDirectory)

$ErrorActionPreference = 'Stop'
$exePath = Join-Path -Path $PSScriptRoot -ChildPath 'HsReconnect.exe'
if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) {
    throw 'Распакуй архив целиком и запусти этот файл из папки рядом с HsReconnect.exe.'
}
if ([string]::IsNullOrWhiteSpace($ShortcutDirectory)) {
    $ShortcutDirectory = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
}
if ([string]::IsNullOrWhiteSpace($ShortcutDirectory)) {
    throw 'Windows не сообщила путь к рабочему столу.'
}

$destination = [IO.Path]::GetFullPath($ShortcutDirectory)
[IO.Directory]::CreateDirectory($destination) | Out-Null
$shortcutPath = Join-Path -Path $destination -ChildPath 'HsReconnect.lnk'
$iconPath = Join-Path -Path $PSScriptRoot -ChildPath 'HsReconnect.ico'
if (-not (Test-Path -LiteralPath $iconPath -PathType Leaf)) { $iconPath = $exePath }

$shell = $null
$shortcut = $null
try {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = [IO.Path]::GetFullPath($exePath)
    $shortcut.WorkingDirectory = $PSScriptRoot
    $shortcut.Arguments = ''
    $shortcut.Description = 'HsReconnect — реконнект Hearthstone и настройки анимаций найма'
    $shortcut.IconLocation = $iconPath + ',0'
    $shortcut.WindowStyle = 1
    $shortcut.Save()
    if (-not (Test-Path -LiteralPath $shortcutPath -PathType Leaf)) {
        throw 'Не удалось сохранить ярлык.'
    }
    Write-Output ('Ярлык создан: ' + $shortcutPath)
}
finally {
    foreach ($comObject in @($shortcut, $shell)) {
        if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
            [Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject) | Out-Null
        }
    }
}
