﻿HsReconnect

ENGLISH
-------

Download and activate

1. Open @HsReconnectBot in Telegram and choose English. Select “Download
   HsReconnect” to get the portable ZIP. Open “My keys” to copy the activation
   key from your paid order. If you have a promo code, choose “Promo code”
   in the bot and reply with it.
2. Use Windows 10 or 11 with .NET Framework 4.7.2 or later. Right-click
   the ZIP and select “Extract All…”. Choose a permanent folder. Keep the
   extracted files together and run the program from that folder.
3. Run HsReconnect.exe and approve the Windows administrator prompt. On first
   launch, choose your language, paste the full key and select “Activate”.
4. HsReconnect looks for Hearthstone automatically. If it asks for the game
   location, select Hearthstone.exe. When setup finishes, look for the
   HsReconnect icon in the notification area next to the clock.

The license is linked to one PC. The 30–365 day license or 7-day free trial
starts when you first activate the key. The trial expires automatically.
HsReconnect uses the internet at every launch to check its
status and expiry against server time. The activation stays in your Windows
profile when you update or move the folder on that PC. For a different PC,
a renewal or a revoked key, get a new key through the bot.

Use HsReconnect

- During a match, when Hearthstone is in the foreground, “Reconnect” appears
  near the game window's bottom-right corner. The button restarts the game
  connection and can be dragged with the mouse.
- Right-click the HsReconnect icon next to the clock to open its menu. Select
  “Settings” → “Language” to change the app language or “Exit HsReconnect”
  to close it.
- If you skipped the game location or moved Hearthstone, use “Battlegrounds
  animations” → “Select Hearthstone.exe…” to update the path.
- For a desktop shortcut, right-click Create-DesktopShortcut.ps1 and select
  “Run with PowerShell”. You can also right-click HsReconnect.exe and use
  “Send to” → “Desktop (create shortcut)”.
- Windows startup requires a protected installation under Program Files.
  From that installation, enable “Battlegrounds animations” →
  “Start with Windows”. For a portable copy in your user folder, open
  HsReconnect manually. Recreate the desktop shortcut after moving the folder.

Updates

Open “Version and updates” from the tray menu to see the app version and
Hearthstone compatibility. Select “Check now” for a manual check. Starting
with version 0.9.5, an internet connection is all you need to receive signed
updates from the public HTTPS channel. HsReconnect checks at launch and
installs an available update when Hearthstone is closed and the animation
modes are inactive. HsReconnect then restarts.

If an earlier version can no longer download 0.9.5 from the old channel,
get the current archive from @HsReconnectBot and install it once. Automatic
updates will then use the new channel.

Optional Battlegrounds animation modes

After first activation, HsReconnect installs the animation module
automatically on a supported game installation. If Hearthstone is open,
close it when prompted. Installation continues as soon as the game closes.
Both modes are on by default once the module is installed. To change them,
open “Battlegrounds animations” in the tray. HsReconnect remembers your
choices. Reduced animations apply to supported effects in the recruit phase.
Faster playback applies to supported Battlegrounds combat. These experimental
modes may affect game stability and your account. Check compatibility after
a Hearthstone update.

To update or remove an installed module, close Hearthstone and choose
“Battlegrounds animations” → “Remove module and restore game file…”. Then
enable the new module if you want to use it. If restoration is unavailable,
use “Scan and Repair” for Hearthstone in Battle.net.

Support

In @HsReconnectBot, open “Help” → “Support” or send /paysupport. Send the full
order number and describe the problem. The reply will appear in that chat.
The app log is reconnect.log next to HsReconnect.exe or in %APPDATA%\HsCopilot
if the extracted folder is read-only.


РУССКИЙ
-------

Скачивание и активация

1. Открой @HsReconnectBot в Telegram и выбери русский. Нажми «Скачать
   HsReconnect», чтобы получить переносной ZIP. В разделе «Мои ключи» скопируй
   ключ из оплаченного заказа. Если у тебя есть промокод, нажми «Промокод»
   и отправь его в ответ на сообщение бота.
2. Нужны Windows 10 или 11 и .NET Framework 4.7.2 или новее. Нажми правой
   кнопкой по ZIP и выбери «Извлечь всё…». Выбери постоянную папку. Храни
   извлечённые файлы вместе и запускай программу из этой папки.
3. Запусти HsReconnect.exe и подтверди запрос прав администратора Windows.
   При первом запуске выбери язык, вставь ключ целиком и нажми «Активировать».
4. HsReconnect ищет Hearthstone автоматически. Если программа попросит
   указать путь к игре, выбери Hearthstone.exe. Когда настройка завершится,
   значок HsReconnect появится в трее рядом с часами.

Лицензия привязывается к одному ПК. Срок от 30 до 365 дней или пробные 7 дней
начинаются с первой активации. Пробный доступ заканчивается автоматически.
При каждом запуске HsReconnect нужен интернет, чтобы сверить статус
и срок лицензии по времени сервера. На том же ПК активация хранится в профиле
Windows и сохраняется при обновлении и переносе папки. Для другого ПК,
продления срока или замены отозванного ключа получи новый ключ в боте.

Работа с HsReconnect

- Во время матча, когда Hearthstone на переднем плане, возле правого нижнего
  угла окна игры появится кнопка «Reconnect». Она перезапускает игровое
  соединение. Кнопку можно перетащить мышью.
- Нажми правой кнопкой по значку HsReconnect рядом с часами. Открой
  «Настройки» → «Язык», чтобы сменить язык программы. Для выхода выбери
  «Закрыть HsReconnect».
- Если ты пропустил выбор игры или перенёс Hearthstone, открой «Анимации
  Battlegrounds» → «Выбрать Hearthstone.exe…» и укажи новый путь.
- Для ярлыка на рабочем столе нажми правой кнопкой по
  Create-DesktopShortcut.ps1 и выбери «Выполнить с помощью PowerShell».
  Ещё один способ — меню файла HsReconnect.exe → «Отправить» →
  «Рабочий стол (создать ярлык)».
- Для автозапуска нужна установка в защищённую папку под Program Files.
  В этой копии отметь «Анимации Battlegrounds» → «Запускать вместе
  с Windows». Переносную копию в папке пользователя открывай вручную.
  После переноса папки создай ярлык заново.

Обновления

Открой в трее «Версия и обновления», чтобы посмотреть версию программы
и совместимость Hearthstone. Для ручной проверки нажми «Проверить сейчас».
Начиная с версии 0.9.5, для получения подписанных обновлений из публичного
HTTPS-канала достаточно подключения к интернету. HsReconnect проверяет
обновления при запуске. Если доступна новая версия, программа применит её
после закрытия Hearthstone и отключения режимов анимаций, затем перезапустится.

Если старая версия уже не может скачать 0.9.5 из прежнего канала, скачай
актуальный архив у @HsReconnectBot и один раз установи его вручную. Дальше
автообновления идут через новый канал.

Дополнительные режимы анимаций Battlegrounds

После первой активации HsReconnect автоматически устанавливает модуль
анимаций в поддерживаемую сборку игры. Если Hearthstone запущен, закрой его,
когда программа об этом попросит. Установка продолжится после закрытия игры.
Оба режима включены по умолчанию после установки модуля. Их можно изменить
в меню «Анимации Battlegrounds» в трее. Программа запоминает твой выбор.
Минимальные анимации применяются к поддерживаемым эффектам в фазе найма,
ускорение — к поддерживаемым боям Battlegrounds. Экспериментальные режимы
могут повлиять на стабильность игры и аккаунт. После обновления Hearthstone
проверь совместимость.

Для обновления или удаления установленного модуля закрой Hearthstone
и выбери «Анимации Battlegrounds» → «Удалить модуль и восстановить файл
игры…». Затем при желании включи новый модуль. Если восстановление
недоступно, запусти проверку и восстановление Hearthstone в Battle.net.

Поддержка

В @HsReconnectBot открой «Помощь» → «Поддержка» или отправь /paysupport.
Укажи полный номер заказа и опиши проблему. Ответ придёт в этот чат.
Журнал программы reconnect.log находится рядом с HsReconnect.exe или
в %APPDATA%\HsCopilot, если папка программы недоступна для записи.


简体中文
--------

下载和激活

1. 在 Telegram 打开 @HsReconnectBot 并选择简体中文。点击「下载 HsReconnect」
   获取便携版 ZIP。在「我的激活码」中打开已付款的订单，复制激活密钥。
   如果有优惠码，点击「优惠码」并回复机器人的消息。
2. 请使用 Windows 10 或 11，并确保已安装 .NET Framework 4.7.2 或更高版本。
   右键单击 ZIP 文件，选择「全部解压缩…」，并指定一个长期使用的文件夹。
   请将解压出的文件放在一起，并从该文件夹启动程序。
3. 运行 HsReconnect.exe，并确认 Windows 的管理员权限提示。首次启动时，选择
   语言，粘贴完整的激活密钥，然后点击「激活」。
4. HsReconnect 会自动查找《炉石传说》。如果程序提示选择游戏位置，请选择
   Hearthstone.exe。设置完成后，可以在时钟旁的系统托盘中找到 HsReconnect 图标。

许可证绑定到一台电脑。30 至 365 天的许可证和 7 天免费试用都从首次激活开始计算。
试用到期后会自动结束。每次启动时，
HsReconnect 都需要联网，并根据服务器时间验证许可证状态和有效期。在同一台
电脑上更新程序或移动文件夹时，Windows 用户配置文件中的激活信息会保留。
如需在另一台电脑上使用、续期或更换已撤销的密钥，请通过机器人获取新的密钥。

使用 HsReconnect

- 对战期间，《炉石传说》窗口处于前台时，游戏窗口右下角附近会出现「Reconnect」
  按钮。点击即可重新建立游戏连接。也可以用鼠标拖动按钮。
- 右键单击时钟旁的 HsReconnect 图标即可打开菜单。选择「设置」→「语言」可以
  更改程序语言。选择「退出 HsReconnect」可以关闭程序。
- 如果之前跳过了游戏位置的选择，或移动了《炉石传说》的安装目录，请选择
  「酒馆战棋动画」→「选择 Hearthstone.exe…」来更新路径。
- 如需创建桌面快捷方式，右键单击 Create-DesktopShortcut.ps1，选择
  「使用 PowerShell 运行」。也可右键单击 HsReconnect.exe，选择
  「发送到」→「桌面快捷方式」。
- 随 Windows 启动要求将程序安装到 Program Files 下的受保护文件夹。
  在该位置启动程序，然后选择「酒馆战棋动画」→「随 Windows 启动」。
  用户文件夹中的便携版请手动打开。移动程序文件夹后，请重新创建快捷方式。

更新

在系统托盘菜单中打开「版本和更新」，可以查看程序版本和《炉石传说》的
兼容性。手动检查时点击「立即检查」。从 0.9.5 版起，只需连接互联网，即可
通过公开的 HTTPS 渠道接收签名更新。HsReconnect 会在启动时检查更新，
并在《炉石传说》已关闭且动画模式已停用时安装新版本，然后重新启动。

如果旧版本已无法从原渠道下载 0.9.5，请从 @HsReconnectBot 获取最新压缩包，
手动安装一次。之后程序会通过新渠道自动更新。

可选的酒馆战棋动画模式

首次激活后，HsReconnect 会在受支持的游戏版本上自动安装动画模块。
如果《炉石传说》正在运行，请按提示关闭游戏，安装会在游戏关闭后继续。
安装模块后，两个模式默认开启。你可以在系统托盘的「酒馆战棋动画」中更改
这两个设置，程序会记住你的选择。简化招募动画适用于招募阶段受支持的效果，
加速播放适用于受支持的酒馆战棋战斗。这些实验性功能可能影响游戏稳定性和账号。
《炉石传说》更新后，请检查兼容性。

更新或移除已经安装的模块时，请先关闭《炉石传说》，然后选择
「酒馆战棋动画」→「移除模块并还原游戏文件…」。之后可以按需启用新的模块。
如果还原功能不可用，请在 Battle.net 中对《炉石传说》执行扫描和修复。

支持

在 @HsReconnectBot 中选择「帮助」→「联系客服」，或发送 /paysupport。请提供
完整的订单编号并描述问题。回复会发送到同一个聊天。程序日志 reconnect.log
位于 HsReconnect.exe 所在文件夹。如果该文件夹不可写，日志会保存在
%APPDATA%\HsCopilot 中。


PORTUGUÊS (BRASIL)
------------------

Baixe e ative

1. Abra @HsReconnectBot no Telegram e selecione Português (Brasil). Escolha
   “Baixar o HsReconnect” para receber o ZIP portátil. Em “Minhas chaves”,
   copie a chave de ativação do pedido pago. Se tiver um código promocional,
   escolha “Código promocional” e responda à mensagem do bot com o código.
2. Use o Windows 10 ou 11 com o .NET Framework 4.7.2 ou posterior. Clique
   com o botão direito no ZIP e selecione “Extrair tudo…”. Escolha uma pasta
   permanente. Mantenha os arquivos extraídos juntos e execute o programa
   a partir dessa pasta.
3. Abra HsReconnect.exe e confirme a solicitação de administrador do Windows.
   Na primeira execução, escolha o idioma, cole a chave inteira e clique em
   “Ativar”.
4. O HsReconnect localiza o Hearthstone automaticamente. Se o programa pedir
   o local do jogo, selecione Hearthstone.exe. Ao concluir a configuração,
   procure o ícone do HsReconnect na área de notificação, ao lado do relógio.

A licença fica vinculada a um computador. O prazo de 30 a 365 dias ou o teste
grátis de 7 dias começa na primeira ativação. O teste termina automaticamente.
A cada execução, o HsReconnect usa a internet para verificar
a situação e a validade da licença pela hora do servidor. No mesmo computador,
a ativação fica no seu perfil do Windows e é mantida ao atualizar ou mover
a pasta. Para usar outro computador, renovar o prazo ou substituir uma chave
revogada, obtenha uma nova chave pelo bot.

Use o HsReconnect

- Durante uma partida, quando o Hearthstone estiver em primeiro plano,
  o botão “Reconnect” aparece perto do canto inferior direito da janela
  do jogo. Ele reinicia a conexão do jogo e pode ser arrastado com o mouse.
- Clique com o botão direito no ícone do HsReconnect, ao lado do relógio.
  Use “Configurações” → “Idioma” para mudar o idioma do programa ou
  “Sair do HsReconnect” para encerrá-lo.
- Se você pulou a escolha da pasta do jogo ou moveu o Hearthstone, use
  “Animações dos Campos de Batalha” → “Selecionar Hearthstone.exe…” para
  atualizar o caminho.
- Para criar um atalho, clique com o botão direito em
  Create-DesktopShortcut.ps1 e escolha “Executar com PowerShell”. Você também
  pode clicar com o botão direito em HsReconnect.exe e usar “Enviar para” →
  “Área de trabalho (criar atalho)”.
- Para iniciar com o Windows, instale em uma pasta protegida dentro de
  Program Files. Nessa instalação, marque “Animações dos Campos de Batalha” →
  “Iniciar com o Windows”. Abra manualmente uma cópia portátil na sua pasta
  de usuário. Se mover a pasta, recrie o atalho.

Atualizações

Abra “Versão e atualizações” no menu da área de notificação para ver a versão
do programa e a compatibilidade com o Hearthstone. Para uma verificação
manual, clique em “Verificar agora”. A partir da versão 0.9.5, basta ter uma
conexão com a internet para receber atualizações assinadas pelo canal HTTPS
público. O HsReconnect verifica se há atualizações ao iniciar. Se houver uma
nova versão, ele a instala quando o Hearthstone estiver fechado e os modos
de animação estiverem inativos. Depois, reinicia.

Se uma versão antiga já não conseguir baixar a 0.9.5 pelo canal anterior,
baixe o pacote atual no @HsReconnectBot e instale-o uma vez. As atualizações
automáticas passarão a usar o novo canal.

Modos opcionais de animação dos Campos de Batalha

Após a primeira ativação, o HsReconnect instala o módulo de animação
automaticamente em uma versão compatível do jogo. Se o Hearthstone estiver
aberto, feche-o quando solicitado. A instalação continuará assim que o jogo
for fechado. Os dois modos são ativados por padrão após a instalação do
módulo. Altere-os em “Animações dos Campos de Batalha” na área de notificação.
O HsReconnect guarda suas escolhas. A redução se aplica aos efeitos
compatíveis da fase de recrutamento, e a reprodução acelerada se aplica aos
combates compatíveis. Esses modos experimentais podem afetar a estabilidade
do jogo e sua conta. Após uma atualização do Hearthstone, verifique a
compatibilidade.

Para atualizar ou remover um módulo instalado, feche o Hearthstone e escolha
“Animações dos Campos de Batalha” → “Remover o módulo e restaurar o arquivo
do jogo…”. Depois, ative o novo módulo se quiser usá-lo. Se a restauração
estiver indisponível, use “Verificar e reparar” no Battle.net para o Hearthstone.

Suporte

No @HsReconnectBot, abra “Ajuda” → “Suporte” ou envie /paysupport. Informe
o número completo do pedido e descreva o problema. A resposta chegará nessa
conversa. O registro reconnect.log fica junto de HsReconnect.exe ou em
%APPDATA%\HsCopilot se a pasta extraída for somente leitura.
